export JRE_DIR="./jre"
rm -rf $JRE_DIR
